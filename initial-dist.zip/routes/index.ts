export { default as rootRoutes } from './root';
