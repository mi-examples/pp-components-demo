declare global {
  interface Window {
    PP_VARIABLES?: Record<string, unknown>;
  }
}
